cd download
rm -f *
cd ../log
rm -f *
cd ../storage1
rm -f *
cd ../storage2
rm -f *
cd ../storage3
rm -f *
cd ../